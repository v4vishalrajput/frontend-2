import { Component } from '@angular/core';

@Component({
    selector:'customer-landing-page',
    templateUrl:'./customer-landing-page.component.html',
    styleUrls:['./customer-landing-page.component.css']
})
export class CustomerLandingPageComponent{
    
}